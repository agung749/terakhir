<?php

return [

    'main_navigation'               => 'প্রধান নেভিগেশান',
    'blog'                          => 'ব্লগ',
    'pages'                         => 'পেজ',
    'account_settings'              => 'অ্যাকাউন্ট সেটিংস',
    'profile'                       => 'প্রোফাইল',
    'change_password'               => 'পাসওয়ার্ড পরিবর্তন করুন',
    'multilevel'                    => 'মাল্টি লেভেল',
    'level_one'                     => 'লেভেল ১',
    'level_two'                     => 'লেভেল ২',
    'level_three'                   => 'লেভেল ৩',
    'labels'                        => 'লেবেল',
    'important'                     => 'গুরুত্বপূর্ণ',
    'warning'                       => 'সতর্কতা',
    'information'                   => 'তথ্য',
];
