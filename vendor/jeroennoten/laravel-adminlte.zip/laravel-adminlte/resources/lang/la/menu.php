<?php

return [

    'main_navigation'               => 'ໜ້າຫຼັກ',
    'blog'                          => 'blog',
    'pages'                         => 'ໜ້າ',
    'account_settings'              => 'ຕັ້ງຄ່າບັນຊີ',
    'profile'                       => 'ໂປຣຟາຍ',
    'change_password'               => 'ປ່ຽນລະຫັດຜ່ານ',
    'multilevel'                    => 'ຫຼາກຫຼາຍລະດັບ',
    'level_one'                     => 'ລະດັບທີ 1',
    'level_two'                     => 'ລະດັບທີ 2',
    'level_three'                   => 'ລະດັບທີ 3',
    'labels'                        => 'ແຖບ',
    'important'                     => 'ສຳຄັນ',
    'warning'                       => 'ຄຳເຕືອນ',
    'information'                   => 'ຂໍ້ມູນ',
];
